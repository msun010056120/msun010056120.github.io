package com.example.d424capstonemsun.UI;

import static org.junit.Assert.assertEquals;
import com.example.d424capstonemsun.entities.UserTable;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class LoginActivityTest {

    // Create a fake user DAO
    private LoginActivity loginActivity;
    private FakeUserDAO fakeUserDao;

    @Before
    public void setUp() {

        loginActivity = new LoginActivity();
        fakeUserDao = new FakeUserDAO();

        loginActivity.userDao = fakeUserDao;

        // Add a test user to simulate an already existing account.
        fakeUserDao.insertUser(new UserTable(0, "validEmail@gmail.com", "password123"));
    }

    @Test
    public void testLoginWithValidCredentials() {
        // Test with valid login credentials.
        boolean result = loginActivity.userDao.login("validEmail@gmail.com", "password123");
        assertEquals(true, result);
    }

    @Test
    public void testLoginWithInvalidCredentials() {
        // Test with wrong login credentials.
        boolean result = loginActivity.userDao.login("wrongEmail@gmail.com", "password321");
        assertEquals(false, result);
    }
}
