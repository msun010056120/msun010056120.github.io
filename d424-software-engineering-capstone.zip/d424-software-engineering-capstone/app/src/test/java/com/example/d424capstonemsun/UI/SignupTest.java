package com.example.d424capstonemsun.UI;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import com.example.d424capstonemsun.entities.UserTable;

@RunWith(RobolectricTestRunner.class)
public class SignupTest extends TestCase{

    private Signup signup;
    private FakeUserDAO fakeUserDao;

    @Before
    public void setUp() {
        signup = new Signup();
        fakeUserDao = new FakeUserDAO();

        signup.userDao = fakeUserDao;
        fakeUserDao.insertUser(new UserTable(0, "hello@gmail.com", "password123"));
    }

    // Check to see if first time signing up with new email works.
    @Test
    public void testCreateAccountSuccess() {

        signup.isAllowed = true;

        String result = signup.createAccount("hello@gmail.com", "password123");

        assertEquals("Account has been created", result);
    }

    // Check if the username or email already been taken
    @Test
    public void testCreateAccountEmailTaken() {
        signup.isAllowed = false;

        String result = signup.createAccount("hello@gmail.com", "password123");

        assertEquals("Email is already taken", result);
    }
}
