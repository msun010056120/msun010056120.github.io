package com.example.d424capstonemsun.UI;

import android.app.AlarmManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.d424capstonemsun.R;
import com.example.d424capstonemsun.database.Repository;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import com.example.d424capstonemsun.entities.Membership;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MembershipDetails extends AppCompatActivity {

    private ImageView imageViewBarcode;

    int membershipID;
    String name;
    String membershipNumber;
    String barcodePic;
    String timestamp;

    Repository repository;
    Membership currentMembership;

    EditText editName;
    EditText editMembershipNum;
    EditText editTimestamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_membership_details);

        imageViewBarcode = findViewById(R.id.imageViewBarcode);

        editName = findViewById(R.id.name);
        editMembershipNum = findViewById(R.id.membershipNum);
        editTimestamp = findViewById(R.id.timestamp);

        repository = new Repository(getApplication());

        membershipID = getIntent().getIntExtra("id", -1);
        name = getIntent().getStringExtra("name");
        membershipNumber = getIntent().getStringExtra("membershipNum");
        barcodePic = getIntent().getStringExtra("barcodePic");
        timestamp = getIntent().getStringExtra("timestamp");

        if (membershipID != -1) {
            currentMembership = repository.getMembershipById(membershipID);

            if (currentMembership != null) {

                editName.setText(currentMembership.getMembershipName());
                editMembershipNum.setText(currentMembership.getMembershipNumber());
                editTimestamp.setText(currentMembership.getTimestamp());
                generateBarcode(currentMembership.getMembershipNumber());

            }
        }

        Button fvB = findViewById(R.id.frontViewButton);
        fvB.setOnClickListener(v ->
        {
            scanCode();
        });

    // Perform live barcode changes based on membershipNum
        editMembershipNum.addTextChangedListener(new TextWatcher() {
     @Override
     public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

     @Override
     public void onTextChanged(CharSequence s, int start, int before, int count) {
         generateBarcode(s.toString());
     }

     @Override
     public void afterTextChanged(Editable s) { }

    });

    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_membership_details, menu);
        return true;
    }

    // Drop-down menu for adding(saving), modifying(updating), and deleting memberships.
    public boolean onOptionsItemSelected(MenuItem item) {
        final String TIMESTAMP_FORMAT = "MM/dd/yyyy HH:mm:ss";
        SimpleDateFormat sdf = new SimpleDateFormat(TIMESTAMP_FORMAT, Locale.US);

        if (item.getItemId() == R.id.membershipdelete) {
            for (Membership member : repository.getmAllMemberships()) {
                if (member.getMembershipID() == membershipID) currentMembership = member;
            }
                repository.delete(currentMembership);
                Toast.makeText(MembershipDetails.this, currentMembership.getMembershipName() + " was deleted.", Toast.LENGTH_LONG).show();
                MembershipDetails.this.finish();
        }

        if (item.getItemId() == R.id.membershipsave) {

            String currentTimestamp = sdf.format(new Date());
            editTimestamp.setText(currentTimestamp);

                Membership membership;
                if (membershipID == -1) {
                    if (repository.getmAllMemberships().size() == 0) membershipID = 1;
                    else
                        membershipID = repository.getmAllMemberships().get(repository.getmAllMemberships().size() - 1).getMembershipID() + 1;
                    membership = new Membership(membershipID,
                            editName.getText().toString(),
                            editMembershipNum.getText().toString(),
                            currentTimestamp);
                    repository.insert(membership);
                    Toast.makeText(MembershipDetails.this, editName.getText().toString() + " was added.", Toast.LENGTH_LONG).show();
                    this.finish();
                } else {
                    membership = new Membership(membershipID,
                            editName.getText().toString(),
                            editMembershipNum.getText().toString(),
                            currentTimestamp);
                    repository.update(membership);
                    Toast.makeText(MembershipDetails.this, editName.getText().toString() + " was updated.", Toast.LENGTH_LONG).show();
                    this.finish();
                }
                return super.onOptionsItemSelected(item);
            }
        return true;
    }
        // Generate a barcode
        @Override
        protected void onResume() {
            super.onResume();
        }
        private void generateBarcode(String text) {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            try {
                Bitmap bitmap = barcodeEncoder.encodeBitmap(text, BarcodeFormat.CODE_128, 400, 200);
                imageViewBarcode.setImageBitmap(bitmap);
            } catch (WriterException e) {
                e.printStackTrace();
            }
        }

        // The ability to use the phone's camera to scan a barcode and output String or numeric input as membershipNum.
        private void scanCode() {
            ScanOptions options = new ScanOptions();
            options.setPrompt("Volumn Up to Turn on Flash");
            options.setBeepEnabled(false);
            options.setOrientationLocked(true);
            options.setCaptureActivity(CaptureAct.class);
            barcodeLauncher.launch(options);
        }

        ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
                result -> {
                    if (result.getContents() != null)
                    {
                        editMembershipNum.setText(result.getContents().toString());
                    }
        });
}
