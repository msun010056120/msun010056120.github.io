package com.example.d424capstonemsun.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d424capstonemsun.R;
import com.example.d424capstonemsun.entities.Membership;

import java.util.ArrayList;
import java.util.List;

public class MembershipAdapter extends RecyclerView.Adapter<MembershipAdapter.MembershipViewHolder> implements Filterable {

    private List<Membership> mMemberships;

    private List<Membership> membershipFull;

    private final Context context;

    private final LayoutInflater mInflater;

    public MembershipAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    public class MembershipViewHolder extends RecyclerView.ViewHolder {

        private final TextView membershipItemView;

        public MembershipViewHolder(@NonNull View itemView) {
            super(itemView);
            membershipItemView = itemView.findViewById(R.id.membershipItem);
            itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final Membership current = mMemberships.get(position);
                    Intent intent = new Intent(context, MembershipDetails.class);
                    intent.putExtra("id", current.getMembershipID());
                    intent.putExtra("name", current.getMembershipName());
                    intent.putExtra("membershipNum", current.getMembershipNumber());
                    intent.putExtra("timestamp", current.getTimestamp());
                    context.startActivity(intent);

                }
            });
        }

    }

    @NonNull
    @Override
    public MembershipAdapter.MembershipViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.membership_item, parent, false);
        return new MembershipViewHolder(itemView);
    }

    // Check to see if membership exist in the Membership / Loyalty List
    @Override
    public void onBindViewHolder(@NonNull MembershipAdapter.MembershipViewHolder holder, int position) {
        if (mMemberships != null) {
            Membership current = mMemberships.get(position);
            String name = current.getMembershipName();
            holder.membershipItemView.setText(name);
        } else {
            holder.membershipItemView.setText("No membership was found.");
        }
    }

    // Get the current item count of the number of membership in the Membership / Loyalty List
    @Override
    public int getItemCount() {
        if (mMemberships != null) {
            return mMemberships.size();
        } else return 0;
    }

    public void setMemberships(List<Membership> memberships) {
        this.mMemberships = memberships;
        this.membershipFull = new ArrayList<>(memberships);
        notifyDataSetChanged();
    }

    // Search function.
    @Override
    public Filter getFilter() {
        return membershipFilter;
    }

    private Filter membershipFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Membership> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(membershipFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Membership item : membershipFull) {
                    if (item.getMembershipName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        // Filter result of memberships during search.
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mMemberships.clear();
            if (results.values != null) {
                mMemberships.addAll((List) results.values);
            }
            notifyDataSetChanged();
        }

    };
}
