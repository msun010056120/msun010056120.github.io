package com.example.d424capstonemsun.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.d424capstonemsun.entities.UserTable;
import com.example.d424capstonemsun.dao.UserDAO;

@Database(entities = {UserTable.class}, version = 1)
public abstract class UsersDatabase extends RoomDatabase {
    public abstract UserDAO getDAO();

}
