package com.example.d424capstonemsun.UI;


import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d424capstonemsun.R;
import com.example.d424capstonemsun.database.Repository;
import com.example.d424capstonemsun.entities.Membership;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class MembershipList extends AppCompatActivity {

    private Repository repository;
    private MembershipAdapter membershipAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_membership_list);
        Button addMembership = findViewById(R.id.addMembership);
        addMembership.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MembershipList.this, MembershipDetails.class);
                startActivity(intent);
            }
        });
        RecyclerView recyclerView = findViewById(R.id.membershipRecyclerView);
        repository = new Repository(getApplication());
        List<Membership> allMemberships = repository.getmAllMemberships();
        membershipAdapter = new MembershipAdapter(this);
        recyclerView.setAdapter(membershipAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        membershipAdapter.setMemberships(allMemberships);

    }

    // Search function for filtering the memberships in the Membership / Loyalty List.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_membership_list, menu);

        // Search functionality
        MenuItem searchItem = menu.findItem(R.id.search);
        androidx.appcompat.widget.SearchView searchView = (androidx.appcompat.widget.SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                membershipAdapter.getFilter().filter(newText);
                return true;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.generateReport) {
            generatePdfReport();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Method to generate the PDF report and save it in the user's local document folder
    private void generatePdfReport() {

        PdfDocument pdfDocument = new PdfDocument();
        Paint paint = new Paint();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create(); // A4 size

        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        paint.setTextSize(24);
        paint.setFakeBoldText(true);
        canvas.drawText("Membership Report", 200, 50, paint);

        paint.setTextSize(14);
        paint.setFakeBoldText(false);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        canvas.drawText("Generated on: " + timestamp, 200, 80, paint);

        paint.setTextSize(16);
        paint.setFakeBoldText(true);
        canvas.drawText("Membership Name", 50, 120, paint);
        canvas.drawText("Membership Number", 225, 120, paint);
        canvas.drawText("Timestamp", 420, 120, paint);

        int y = 150;
        paint.setFakeBoldText(false);

        for (Membership membership : repository.getmAllMemberships()) {
            canvas.drawText(membership.getMembershipName(), 50, y, paint);
            canvas.drawText(membership.getMembershipNumber(), 225, y, paint);
            canvas.drawText(membership.getTimestamp().toString(), 420, y, paint);
            y += 30;
        }

        pdfDocument.finishPage(page);

        try {

            File documentsDir = new File(Environment.getExternalStorageDirectory(), "Documents/EazyCard");
            if (!documentsDir.exists()) {
                documentsDir.mkdirs();
            }

            File file = new File(documentsDir, "MembershipReport.pdf");
            FileOutputStream fos = new FileOutputStream(file);

            pdfDocument.writeTo(fos);
            fos.close();

            Toast.makeText(this, "PDF saved to Documents/EazyCard", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        pdfDocument.close();
    }

    // On resume, get the latest Membership / Loyalty List
    @Override
    protected void onResume(){

        super.onResume();
        List<Membership> allMemberships = repository.getmAllMemberships();
        RecyclerView recyclerView=findViewById(R.id.membershipRecyclerView);
        membershipAdapter.setMemberships(allMemberships);
        membershipAdapter.notifyDataSetChanged();

    }
}