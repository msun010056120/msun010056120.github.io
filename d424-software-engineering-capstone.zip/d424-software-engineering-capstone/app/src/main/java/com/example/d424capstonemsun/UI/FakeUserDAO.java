package com.example.d424capstonemsun.UI;


import com.example.d424capstonemsun.dao.UserDAO;
import com.example.d424capstonemsun.entities.UserTable;

import java.util.ArrayList;
import java.util.List;

public class FakeUserDAO implements UserDAO {

    // Simulate the UserTable List
    private List<UserTable> userList = new ArrayList<>();

    @Override
    public void insertUser(UserTable user) {
        userList.add(user);
    }

    @Override
    public boolean login(String email, String password) {
        // Simulate login by checking email and password.
        for (UserTable user : userList) {
            if (user.getEmail().equals(email) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean is_taken(String email) {
        // Simulate checking to see if the email is taken.
        for (UserTable user : userList) {
            if (user.getEmail().equals(email)) {
                return true;
            }
        }
        return false;
    }
}