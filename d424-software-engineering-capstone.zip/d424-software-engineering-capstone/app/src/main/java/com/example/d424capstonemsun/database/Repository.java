package com.example.d424capstonemsun.database;

import android.app.Application;
import android.provider.MediaStore;

import com.example.d424capstonemsun.dao.MembershipDAO;
import com.example.d424capstonemsun.entities.Membership;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {

    private MembershipDAO mMembershipDAO;

    private List<Membership> mAllMemberships;

    private static int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    // Repository for MembershipDAO
    public Repository(Application application) {
        LoyaltyDatabaseBuilder db = LoyaltyDatabaseBuilder.getDatabase(application);
        mMembershipDAO = db.membershipDAO();
    }

    // Get All Stored Membership
    public List<Membership> getmAllMemberships() {
        databaseExecutor.execute(() -> {
            mAllMemberships = mMembershipDAO.getAllMemberships();
        });

        try {
            Thread.sleep(1000);

        } catch (InterruptedException e) {

            throw new RuntimeException(e);
        }
        return mAllMemberships;
    }

    // Insert New Membership Information
    public void insert(Membership membership) {
        databaseExecutor.execute(() -> {
            mMembershipDAO.insert(membership);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Update Membership Information
    public void update(Membership membership) {
        databaseExecutor.execute(() -> {
            mMembershipDAO.update(membership);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Delete Membership Information
    public void delete(Membership membership) {
        databaseExecutor.execute(() -> {
            mMembershipDAO.delete(membership);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Get Membership by membershipID
    public Membership getMembershipById(int membershipID) {
        final Membership[] membership = new Membership[1];
        databaseExecutor.execute(() -> {
            membership[0] = mMembershipDAO.getMembershipById(membershipID);
        });

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return membership[0];
    }
}
