package com.example.d424capstonemsun.entities;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "memberships")
public class Membership {

    @PrimaryKey(autoGenerate = true)

    private int membershipID;

    private String membershipName;

    private String membershipNumber;

    private String timestamp;

    public Membership(int membershipID, String membershipName, String membershipNumber, String timestamp){
        this.membershipID = membershipID;
        this.membershipName = membershipName;
        this.membershipNumber = membershipNumber;
        this.timestamp = timestamp;
    }

    public String toString(){
        return membershipName;
    }

    public int getMembershipID() {
        return membershipID;
    }

    public void setMembershipID(int membershipID) {
        this.membershipID = membershipID;
    }

    public String getMembershipName() {
        return membershipName;
    }

    public void setMembershipName(String membershipName) {
        this.membershipName = membershipName;
    }

    public String getMembershipNumber() {
        return membershipNumber;
    }

    public void setMembershipNumber(String membershipNumber) {this.membershipNumber = membershipNumber; }

    public String getTimestamp() { return timestamp; }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

}
