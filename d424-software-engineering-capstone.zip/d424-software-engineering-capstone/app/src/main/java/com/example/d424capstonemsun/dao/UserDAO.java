package com.example.d424capstonemsun.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.d424capstonemsun.entities.UserTable;

@Dao
public interface UserDAO {

    // Insert User into UserTable
    @Insert
    void insertUser(UserTable userTable);

    // Check to see if the email/username is already taken or stored in the UserTable during create account.
    @Query("SELECT EXISTS (SELECT * FROM UserTable WHERE email=:email)")
    boolean is_taken(String email);

    // Login, if the proper email and password is provided and matches what is already stored in the UserTable.
    @Query("SELECT EXISTS (SELECT * FROM UserTable WHERE email=:email AND password=:password)")
    boolean login(String email, String password);

}
