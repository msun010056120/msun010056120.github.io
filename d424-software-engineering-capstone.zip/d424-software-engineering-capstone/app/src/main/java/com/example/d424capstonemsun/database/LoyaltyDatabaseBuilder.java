package com.example.d424capstonemsun.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.d424capstonemsun.dao.MembershipDAO;
import com.example.d424capstonemsun.entities.Membership;

@Database(entities = {Membership.class}, version = 1, exportSchema = false)
public abstract class LoyaltyDatabaseBuilder extends RoomDatabase {
    public abstract MembershipDAO membershipDAO();
    public static volatile LoyaltyDatabaseBuilder INSTANCE;

    static LoyaltyDatabaseBuilder getDatabase(final Context context){
        if(INSTANCE==null){
            synchronized (LoyaltyDatabaseBuilder.class){
                if(INSTANCE==null){
                    INSTANCE= Room.databaseBuilder(context.getApplicationContext(),LoyaltyDatabaseBuilder.class, "LoyaltyDatabase.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
