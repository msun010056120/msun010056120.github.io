package com.example.d424capstonemsun.UI;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.d424capstonemsun.R;
import com.example.d424capstonemsun.dao.UserDAO;
import com.example.d424capstonemsun.database.UsersDatabase;
import com.example.d424capstonemsun.databinding.ActivityMainBinding;

public class LoginActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    UsersDatabase userDB;
    UserDAO userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership_list);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userDB = Room.databaseBuilder(this, UsersDatabase.class, "usertable")
                .allowMainThreadQueries().fallbackToDestructiveMigration().build();
        userDao = userDB.getDAO();

        binding.loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.existingEmailAddress.getText().toString();
                String password = binding.existingPassword.getText().toString();

                String result = login(email, password);

                if ("success".equals(result)) {
                    startActivity(new Intent(LoginActivity.this, MembershipList.class));
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Email Address or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        findViewById(R.id.signupButton).setOnClickListener(view -> {
            startActivity(new Intent(LoginActivity.this, Signup.class));
        });
    }

    public String login(String email, String password) {
        if (userDao.login(email, password)) {
            return "success";
        } else {
            return "Invalid Email Address or Password";
        }
    }
}
