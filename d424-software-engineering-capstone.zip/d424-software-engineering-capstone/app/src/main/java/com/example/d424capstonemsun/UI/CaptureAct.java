package com.example.d424capstonemsun.UI;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity {
// Class for reading barcode with the camera
}
