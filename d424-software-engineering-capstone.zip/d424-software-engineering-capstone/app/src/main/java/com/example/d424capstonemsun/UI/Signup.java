package com.example.d424capstonemsun.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.d424capstonemsun.R;
import com.example.d424capstonemsun.dao.UserDAO;
import com.example.d424capstonemsun.database.UsersDatabase;
import com.example.d424capstonemsun.databinding.ActivitySignupBinding;
import com.example.d424capstonemsun.entities.UserTable;

public class Signup extends AppCompatActivity {

    ActivitySignupBinding binding;
    UsersDatabase userDB;
    UserDAO userDao;
    public static boolean isAllowed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userDB = Room.databaseBuilder(this, UsersDatabase.class, "usertable")
                .allowMainThreadQueries().fallbackToDestructiveMigration().build();
        userDao = userDB.getDAO();


        binding.newEmailAddress.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void afterTextChanged(Editable editable) {
                String email = editable.toString();
                if (userDao.is_taken(email)) {
                    isAllowed = false;
                    Toast.makeText(Signup.this, "This Email is Already Taken", Toast.LENGTH_SHORT).show();
                } else {
                    isAllowed = true;
                }
            }
        });

        // Notify the user if the account have been successfully created.
        binding.createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.newEmailAddress.getText().toString();
                String password = binding.newPassword.getText().toString();

                String result = createAccount(email, password);
                Toast.makeText(Signup.this, result, Toast.LENGTH_SHORT).show();

                if (result.equals("Account has been created")) {
                    startActivity(new Intent(Signup.this, LoginActivity.class));
                }
            }
        });


        Button goToHome = findViewById(R.id.goToHomeScreen);
        goToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Signup.this, LoginActivity.class);
                intent.putExtra("Testing", "Information Transfer");
                startActivity(intent);
            }
        });
    }

    // Used for creating an account for the unit Test for Signup Test
    public String createAccount(String email, String password) {
        if (isAllowed) {
            UserTable userTable = new UserTable(0, email, password);
            userDao.insertUser(userTable);
            return "Account has been created";
        } else {
            return "Email is already taken";
        }
    }
}
