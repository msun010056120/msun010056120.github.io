package com.example.d424capstonemsun.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.d424capstonemsun.entities.Membership;
import java.util.List;

@Dao
public interface MembershipDAO{

    // Insert Membership Information
    @Insert(onConflict= OnConflictStrategy.IGNORE)
    void insert(Membership membership);

    // Update Membership Information
    @Update
    void update(Membership membership);

    // Delete Membership Information
    @Delete
    void delete(Membership membership);

    // Select All Memberships for the Memberships Table and sort it in ascending order
    @Query("SELECT * FROM MEMBERSHIPS ORDER BY membershipID ASC")
    List<Membership> getAllMemberships();

    // Select Membership where membershipID == membershipID, Limit to 1
    @Query("SELECT * FROM MEMBERSHIPS WHERE membershipID = :membershipID LIMIT 1")
    Membership getMembershipById(int membershipID);

}

