
## Readme file for D424 - Software Engineering Capstone

Author: Ming Chi Sun
StudentID: 010056120

- Title: D424-software-engineering-capstone (EazyCard) - D424 Capstone (M.Sun)
- Purpose: Develop an app that can store membership information from scanning barcode of physical membership / loyalty card.

## How to use the application

- Login Activity (Home Page)

    Contains the home screen of the EazyCard app, it gives the user the option to login if they have an account or to sign up for one.

- Membership List

    Contains the list of membership(s) that the user have added and its details.

    It also contains an add (+) button to add new membership, a search button, and a save file button (generate report).

- Membership Details

    Contains the information for each membership and the ability to save/update and delete the membership information and capture the membership number with a barcode scanner.

    It includes the following fields:
	- Name
	- Membership #
	- Last Updated

    Contains a timestamp functionality during update/save.
    
    The Drop-down menu gives you the option to:
	- Save/Update Membership
	- Delete Membership

    It also contains an add (Capture Barcode) button.

- Membership List

    Contains the list of membership(s) that the user can add to or have added.

    The Membership allows the user to:
	- Search for membership
	- Generate a pdf of the list of membership
	- Add membership

- activity_membership_list.xml

    The layout file membership list and it's associated functions such as search and generate report.

- membership_item.xml

    Serves as an item unit in the list of memberships.

- activity_main.xml

    Serves as a the login page.

- activity_signup.xml

    Gives the user the option create an account.
	
- activity_membership_details.xml

	Gives the user the option to save(add/update), delete the membership, and capture the barcode by using the camera.
	
- menu_membership_details.xml

	Serves as the drop-down menu for membership details.
	
- menu_membership_list.xml

	Serves as the drop-down menu for membership list.
	

## Android Version Compatibility


- Minimum SDK: Android 8.0 (Oreo) - API level 26
- Target SDK: Android 13 - API level 34

## GitRepository

- https://gitlab.com/wgu-gitlab-environment/student-repos/Ming_Chi_Sun/d424-software-engineering-capstone.git